"""Azure OpenAI adapters."""
