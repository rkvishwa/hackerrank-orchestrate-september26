"""Azure OpenAI adapters."""
