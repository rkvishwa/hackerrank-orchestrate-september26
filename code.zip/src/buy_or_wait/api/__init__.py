"""FastAPI application package."""
