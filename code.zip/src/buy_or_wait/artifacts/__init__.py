"""Artifact generation helpers."""
